# Steps to run the file

Follow the steps to run the program :

1. Extract the zip named 1700200021

2. Open terminal inside 1700200021, run this command to run the master 
`go run ./master_client.go  -m 127.0.0.1:8000 1 ./slavesfile "masterLogger"`

3. For each slave, run the corresponding command:
`go run ./master_client.go -s 127.0.0.1:8001 1 "slaveLogger1";`

4. Check the logs.

# Steps to make common Log file to visualize in Shiviz

1. Go to the bin folder inside `Go` file in your pc which contains the `GoVector` executable file.

2. Run this command `./GoVector --log_type shiviz --log_dir {location of the folder} --outfile output.log`

### References

1. https://github.com/DistributedClocks/GoVector

2. https://bestchai.bitbucket.io/shiviz/

3. https://github.com/daniel-almeida/BerkeleyAlgorithm


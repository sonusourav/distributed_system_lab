package main
import (
	"fmt"
	"log"
	"net/http"
	"net/rpc"
	"io/ioutil"
	"os"
	"bufio"
	"strconv"
)

type Listener int

type Response struct {
	Data string
	TransNo string
}

type Request struct {
	Data int
	TransNo string
}

var TransIds []string
var index int
var balance int

func (l *Listener) GetBalance(args *Request, response *Response) error {
	//Implement the logic to check the transaction already processed if processed add appropriate message into Response
	transno := args.TransNo

	found := contains(TransIds, transno)
	if found {
		(*response).Data = "The transaction already processed."
		return nil
	}

	//Else Implement the logic to add the transaction id into TransIds array and Trans_Processed.txt file
	//adding the transaction no to TransId array
	TransIds = append(TransIds, transno)
	index++
	
	//adding the transaction to Trans_Processed file
	f, err := os.OpenFile("Trans_Processed.txt", os.O_APPEND|os.O_WRONLY, 0644)
	if err != nil {
		fmt.Println(err)
	}
	_, err = f.WriteString("\n"+args.TransNo)
	if err != nil {
		fmt.Println(err)
		defer f.Close()
	}

	//Implement the logic to read the Balance from Balance.txt
	data, err := ioutil.ReadFile("Balance.txt")
	if err != nil {
		fmt.Errorf("Balance file reading error %s", err)
	}

	//Implement the logic to add Balance and Transaction ID to the response
	(*response).Data = string(data)
	(*response).TransNo = args.TransNo	
	
	return nil
}

//function to check if the array contains the given element
func contains(array []string, toFind string) bool {
    for _, item := range array {
        if item == toFind {
            return true
        }
    }
    return false
}

func (l *Listener) DepositeAmount(args *Request, response *Response) error {
	//Implement the logic to check the transaction already processed if processed add appropriate message into Response
	found := contains(TransIds, args.TransNo)
	if found{
		(*response).Data = "The transaction already processed."
		return nil
	}

	//Else Implement the logic to add the transaction id into TransIds array and Trans_Processed.txt file
	
		//adding the transaction no to TransId array
		TransIds = append(TransIds, args.TransNo)
		index++
	
		//adding the transaction to Trans_Processed file
		f, err := os.OpenFile("Trans_Processed.txt", os.O_APPEND|os.O_WRONLY, 0644)
		if err != nil {
			fmt.Println(err)
		}

		_, err = f.WriteString("\n"+args.TransNo)
		if err != nil {
			fmt.Println(err)
			defer f.Close()
		}
	
		//Implement the logic to read the balance and add the amount to into balance 
		data, err := ioutil.ReadFile("Balance.txt")
		if err != nil {
			fmt.Println("Balance file reading error", err)
		}

		balance, _ := strconv.Atoi(string(data))
		newBalance := balance + args.Data

		//write calculated balance back to Balance.txt
		file, err := os.OpenFile("Balance.txt", os.O_RDWR, 0644)
		if err != nil { return nil }
		defer file.Close()

		_, err = file.WriteString(strconv.Itoa(newBalance))
		if err != nil { return nil}

		//Implement the logic to add Balance and Transaction ID to the response
		response.Data = "Your Amount is deposited into the account successfully."
		
		return nil	
}


func main() {
	//Read the transaction processed from Trans_Processed.txt into TransIds
	file, err := os.Open("Trans_Processed.txt") 
  
    if err != nil { 
        log.Fatalf("Failed to open Trans_Processed file") 
    } 
  
    scanner := bufio.NewScanner(file) 
    scanner.Split(bufio.ScanLines) 
  
    for scanner.Scan() { 
		TransIds = append(TransIds, scanner.Text()) 
		index++
    } 
	
	//Sample code to start the server, read the port number from command-line
	listener := new(Listener)
	rpc.Register(listener)
	rpc.HandleHTTP()

	err = http.ListenAndServe(":8098", nil)
	if err != nil {
		fmt.Println(err.Error())
	}
}


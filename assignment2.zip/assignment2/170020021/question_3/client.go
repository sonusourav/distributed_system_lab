package main

import (
	"fmt"
   "log"
   "net/rpc"
   "time"
)
type Response struct {
   Data string
   TransNo string
}

type Request struct {
	Data int
	TransNo string
}

func main() {

	//Sample code to connect to server using HTTP
	var serverAddress = "localhost"
	client, err := rpc.DialHTTP("tcp", serverAddress+":8098")
	if err != nil {
		fmt.Println(err)
	}

	//Implement the logic to generate the transaction id using date and time and construct the request.
	var currentDateAndTime = time.Now()
	args1 := new(Request)
	args1.TransNo = currentDateAndTime.Format("02-01-2006 15:04:05 Monday")
	args1.Data = 100

	//Sample code to make async call to server
	response1 := new(Response)
	divCall := client.Go("Listener.DepositeAmount", args1, response1, nil)
	if divCall == nil {
		log.Fatal(divCall)
	}

	time.Sleep(2 * time.Second)

	currentDateAndTime = time.Now()
	args2 := new(Request)
	args2.TransNo = currentDateAndTime.Format("02-01-2006 15:04:05 Monday")

	//Sample code to make async call to server
	response2 := new(Response)
	divCall = client.Go("Listener.GetBalance", args2, response2, nil)
	if divCall == nil {
		log.Fatal(divCall)
	}

	//Wait for the transanctions complete
	time.Sleep(6 * time.Second)

	//Display the response
	log.Printf("Response1: Transaction Number - %v : %v", response1.TransNo, response1.Data)
	log.Printf("Response2: Transaction Number - %v : %v",response2.TransNo, response2.Data)	
}

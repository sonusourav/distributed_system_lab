## Follow the below command to compile and generate the jar file:

1. Open terminal in the Wordcount folder.

2. Run the following commands:
a) sbt clean
b) sbt update
c) sbt compile
d) sbt assembly

3. The output jar will be generated inside the scala-2.12 folder inside target folder as Scala_Hadoop-assembly-1.0.jar.
 Rename it to Wordcount_Assignment4.jar and save it to Desktop.

4. Create an input file as input_data.txt in the Desktop.

5. Store the input file in the hdfs using the below command:
hadoop fs -put /Users/sonusourav/Desktop/input_data.txt /input_data

## Run the below command to run the program

1. hadoop jar /Users/sonusourav/Desktop/WordCount_Assignment4.jar assignment/WordCount /input_data /output

## Copy from hadoop file system to Local

1 Run the below command to copy the output from hadoop filesystem to Local
hadoop fs -copyToLocal /output ~/Desktop
package main
import (
    "fmt"
    "net"
    "bufio"
)

func main() {
    response :=  make([]byte, 2048)
    const ipAddress = "10.250.1.101:8090"

    // Although we're not in a connection-oriented transport,
	// the act of `dialing` is analogous to the act of performing
	// a `connect(2)` syscall for a socket of type SOCK_DGRAM:
	// - it forces the underlying socket to only read and write
	//   to and from a specific remote address.    
    conn, err := net.Dial("udp", ipAddress)
    if err != nil {
        fmt.Printf("Some error occured: %v", err)
        return
    }

    //Broadcasting message to the server
    fmt.Fprintf(conn, "My name is SonuSourav, My roll no is 170020021, What is the sum of numbers in my roll no?")

    //Listening to the response form the server
    _, err = bufio.NewReader(conn).Read(response)
    if err == nil {
        fmt.Printf("%s\n", response)
    } else {
        fmt.Printf("Some error occured: %v\n", err)
    }

    // Closes the underlying file descriptor associated with the
	// socket so that it no longer refers to any file.
    conn.Close()
}
For running the program, follow the below steps:

1. Unzip  the folder.
2. Open terminal in the same.
3. Make sure to connect to 10.250.1.101:8090 using Fortinet.
4. Run this command in the terminal : go run udpclient.go

Code Overview

1. First we need to connect to server using the `net.Dial("udp", ipAddress)` line. 
2. Then the client sends the provided message to the server using `fmt.Fprintf(conn, message)` line.
3. The server responds back to the client with some message which is implemented using `bufio.NewReader(conn).Read(response)` line.
4. The connection is closed so that it no longer refers to any file.

Learning Involved:

While testing the program, it was giving `Connection Refused`. I checked and was able to ping the IP address but could not reach out to the port. I verified by using
`telnet` command. However, it become available after 3 hours when I rechecked it.

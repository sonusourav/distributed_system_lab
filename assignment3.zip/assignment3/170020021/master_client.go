package main

import (
	"fmt"
	"os"
	"strconv"
	"bufio"
	"encoding/json"
	"net"
	"sort"
	"time"

	"github.com/DistributedClocks/GoVector/govec"
)

// Logger ...
var Logger *govec.GoLog

func main() {
	// Check number of arguments
	numberOfArgs := len(os.Args)
	if numberOfArgs < 5 {
		panic("Not enough arguments.")
	}

	// Get the address
	address := os.Args[2]

	// Get the initialized time
	initialClockTime := os.Args[3]
	initialClock, err := strconv.Atoi(initialClockTime)
	checkError(err)

	// Parse flag (master or slave)
	isMasterOrSlaveFlag := os.Args[1]
	if isMasterOrSlaveFlag == "-m" {
		// Master is running
		if numberOfArgs != 6 {
			panic("Expected 6 arguments.")
		}

		slavesFile := os.Args[4]

		logFileName := os.Args[5]

		//Initialize GoVector Master logger
		Logger = govec.InitGoVector("Master-"+address, logFileName, govec.GetDefaultConfig())

		master := Master{address, initialClock, make(map[string]*Slave), 0}
		master.loadSlavesFromFile(slavesFile)
		master.run()

	} else if isMasterOrSlaveFlag == "-s" {
		// Slave is running
		if numberOfArgs != 5 {
			panic("Expected 5 arguments.")
		}

		logFileName := os.Args[4]

		//Initialize GoVector logger
		Logger = govec.InitGoVector("Slave-"+address, logFileName, govec.GetDefaultConfig())

		slave := Slave{address, initialClock, -1}
		slave.run()
	} else {
		panic("Flag should be -m or -s")
	}
}

func checkError(err error) bool {
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
		return true
	}
	return false
}

//Slave struct
type Slave struct {
	Address string
	Clock   int
	Delta   int
}

//Slaves array
type Slaves []Slave

func (slice Slaves) Len() int {
	return len(slice)
}

func (slice Slaves) Less(i, j int) bool {
	return slice[i].Clock < slice[j].Clock
}

func (slice Slaves) Swap(i, j int) {
	slice[i], slice[j] = slice[j], slice[i]
}

func (s *Slave) run() {
	go startClock(&s.Clock)

	// Set up UDPConn
	conn := createUDPConn(s.Address) 
	defer conn.Close()

	lastKnownSyncRound := -1
	for {
		senderAddress, message := readMessage(conn)
		fmt.Println("time of slave ", s.Address, " on ", message.Type," = ", s.Clock)

		switch message.Type {
		// Master is requesting local clock
		case "CLOCK_REQUEST":
			lastKnownSyncRound = message.SyncRound

			var t1 int // master's clock
			err := json.Unmarshal(message.Body, &t1)
			if err != nil {
				fmt.Println(err)
				continue
			}

			t2 := s.Clock // local clock
			fmt.Println("before sending in slave", s.Address, " clock = ", s.Clock)

			// Send local clock back to Master
			clockResponseMessage := newMessage(message.SyncRound, "CLOCK_RESPONSE", ClockData{T1: t1, T2: t2})
			sendMessage(conn, senderAddress, clockResponseMessage)

		//Master sends message to slave to update its local time
		case "CLOCK_UPDATE":
			if message.SyncRound < lastKnownSyncRound {
				// Late message from an earlier synchronization round
				continue
			}

			// Update local clock (sync)
			var clockOffset int
			err := json.Unmarshal(message.Body, &clockOffset)
			if err != nil {
				fmt.Println(err)
				continue
			}
			s.Clock = s.Clock + clockOffset
		}
	}
}





//Master struct 
type Master struct {
	listenAddress string
	Clock         int
	Slaves        map[string]*Slave
	SyncRound     int
}


var conn net.PacketConn

func (m *Master) run() {
   var timeoutTime int = 1

	go startClock(&m.Clock)

	// Set up UDPConn
	conn = createUDPConn(m.listenAddress)
	defer conn.Close()

	// Start listener to hear back from Slaves
	go m.listenToSlaves()

	for {
		requestMessage := newMessage(m.SyncRound, "CLOCK_REQUEST", m.Clock)
		for _, v := range m.Slaves {
			//v.Clock = -1
			go sendMessage(conn, v.Address, requestMessage)
		}

		fmt.Println("master clock ", m.Clock)


		syncRoundTimeout := time.NewTimer(time.Second * time.Duration(timeoutTime))
		<-syncRoundTimeout.C

		// Update syncRound. Messages received from now on will be ignored until the next sendClockRequest
		m.SyncRound++

		// Calculate fault-tolerant average
		validSlaves := make(Slaves, 0)
		for _, v := range m.Slaves {
			fmt.Println("received clock of slave ", v.Address, " = ", v.Clock)
			if v.Clock > -1 {
				validSlaves = append(validSlaves, *v)
			}
		}

		avg := calculateAvg(validSlaves)

		fmt.Println("average = ", avg)

		// Send updated clock to each slave
		for _, v := range m.Slaves {
			offset :=   v.Delta - avg
			fmt.Println(" master clock = ", m.Clock, " slave: ", v.Address, "delta = ", v.Delta ," offset = ", offset)
			go sendMessage(conn, v.Address, newMessage(m.SyncRound, "CLOCK_UPDATE", offset))
		}

		// Update Master's clock as well
		m.Clock = m.Clock - avg
	}
}

func calculateAvg(slavesAlive Slaves) int {
	sort.Sort(slavesAlive)
	avg := 0
	totalDelta := 0
	sizeOfSubset := 1

	for _, v := range slavesAlive{
		totalDelta += v.Delta
		sizeOfSubset++
	}

	avg = totalDelta / sizeOfSubset
	

	return avg
}

func (m *Master) listenToSlaves() {
	for {
		senderAddress, message := readMessage(conn)
		t3 := m.Clock

		if message.Type != "CLOCK_RESPONSE" {
			fmt.Println("Received invalid message.")
			continue
		}

		if message.SyncRound < m.SyncRound {
			fmt.Println("Message out syncRound.")
			continue
		}

		var data ClockData
		err := json.Unmarshal(message.Body, &data)
		if err != nil {
			fmt.Println(err)
			continue
		}

		delta := (data.T1 / t3)/2 - (data.T2) 
		m.Slaves[senderAddress].Clock = data.T2
		m.Slaves[senderAddress].Delta = delta
	}
}

func startClock(clock *int) {
	ticker := time.NewTicker(1 * time.Second)

	for _ = range ticker.C {
		*clock++
	}
}

func (m *Master) loadSlavesFromFile(path string) {
	// Read slavesfile to get list of slaves (host:ip) to connect with
	f, err := os.Open(path)
	checkError(err)
	defer f.Close()

	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		slaveAddress := scanner.Text()
		m.Slaves[slaveAddress] = &Slave{slaveAddress, -1, -1}
	}
}

type Message struct {
	SyncRound int
	Type      string
	Body      json.RawMessage
}

type ClockData struct {
	T1 int
	T2 int
}

func createUDPConn(address string) net.PacketConn {
	conn, err := net.ListenPacket("udp", address)
	checkError(err)

	return conn
}

func sendMessage(conn net.PacketConn, address string, message Message) {
	rAddr, err := net.ResolveUDPAddr("udp", address)
	if checkError(err) {
		return
	}

	messageJSON, err := json.Marshal(&message)
	if err != nil {
		fmt.Println(err)
	}

	//Encode message, and Log vector clock
	sendingMessage := fmt.Sprintf("Sending %s Message", message.Type)
	vectorclockmessage := Logger.PrepareSend(sendingMessage, messageJSON, govec.GetDefaultLogOptions())

	//send message
	_, err = conn.WriteTo(vectorclockmessage, rAddr)
	
	checkError(err)
}

func readMessage(conn net.PacketConn) (string, Message) {
	vectorclockmessage := make([]byte, 1024)
	var tempMessage, message Message

	messageInJSON, err := json.Marshal(&tempMessage)
	if err != nil {
		fmt.Println(err)
	}

	//Receive message
	_, senderAddress, err := conn.ReadFrom(vectorclockmessage[0:])
	checkError(err)

	//Decode message, and update local vector clock
	receivedMessage := fmt.Sprintf("Receiving %s Message", message.Type)
	Logger.UnpackReceive(receivedMessage, vectorclockmessage, &messageInJSON, govec.GetDefaultLogOptions())

	err = json.Unmarshal(messageInJSON, &message)
	checkError(err)

	return senderAddress.String(), message
}

func newMessage(syncRound int, messageType string, data interface{}) Message {
	message := Message{
		SyncRound: syncRound,
		Type:      messageType,
	}

	if data != nil {
		dataJSON, err := json.Marshal(&data)
		checkError(err)
		message.Body = dataJSON
	}

	return message
}
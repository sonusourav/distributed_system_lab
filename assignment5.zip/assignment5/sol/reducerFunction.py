import sys

proportion = [ float(x) for x in sys.argv[1:] ]
grads = [0 for w in proportion]

count = 0

for line in sys.stdin:
    count += 1
    line = list(map(float, line.strip().split()))
    for i, num in enumerate(line):
        grads[i] += num


finalReducerValue = [ w - g/count for w, g in zip(proportion, grads) ]
finalReducerValue = map(str, finalReducerValue)
finalReducerValue = ' '.join(finalReducerValue)
print(finalReducerValue)
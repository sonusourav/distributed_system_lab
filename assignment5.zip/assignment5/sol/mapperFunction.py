import sys

e = 2.71828
proportion = [ float(x) for x in sys.argv[1:] ]


def gradient(iter):
    X = iter[:-1]
    y = iter[-1]

    z = sum( x*w for x, w in zip(X,proportion) )
    s = 1. / (1. + e**-z)
    return [x * (s - y) for x in X]
    

for iter in sys.stdin:
    iter = list( map(float, iter.strip().split()) )
    iter = gradient(iter)
    iter = ' '.join(map(str, iter))
    print(iter)
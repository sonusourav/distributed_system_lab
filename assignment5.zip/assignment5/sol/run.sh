#!/bin/bash

cp weights.init weights.current;
start=$(python -c "import time; print(time())");

for i in {1..100}
do
    ./run_first.sh > /dev/null 2>&1
    hadoop fs -get -f output_dir/part-00000 weights.current > /dev/null 2>&1
    hadoop fs -rm -r -f output_dir > /dev/null 2>&1

    end=$(python -c "from time import time; print(time())");
    echo "$end $start" | awk '{print $1-$2}' >> times.txt
    echo "Done with iteration" $i
done

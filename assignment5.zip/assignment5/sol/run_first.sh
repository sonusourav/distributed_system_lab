weights=$(cat weights.current)
hadoop jar $HADOOP_HOME/libexec/libexec/tools/hadoop-streaming.sh \
-file "mapperFunction.py"    -mapper "python mapperFunction.py $weights" \
-file "reducerFunction.py"   -reducer "python reducerFunction.py $weights" \
-input input_dir/ -output output_dir/
